from .registry import ProductRegistry
