from .service import GlobalCatalog
